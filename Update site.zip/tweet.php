<?php
// Consumer key - found under "OAuth settings" in Twitter application details
$consumer_key = '';
// Consumer secret - found under "OAuth secret" in Twitter application details
$consumer_secret = '';
// Access token - found under "Your access token" in Twitter application details
$access_token = '';
// Access token secret - found under "Your access token" in Twitter application details
$access_token_secret = '';
?>