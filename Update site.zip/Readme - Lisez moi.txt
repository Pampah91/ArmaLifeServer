<Auteur original>

Theme Name: Maxim
Theme URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com


<Modifications apport�es>

par Pampah, pour le site du serveur ArmaRealLife (A4L)